const axios = require("axios");
require("dotenv").config();

const API_KEY = process.env.OPENWEATHERMAP_API_KEY;
const BASE_URL = "https://api.openweathermap.org/data/2.5";
const endpoint = "/weather?id=524901&appid=8fe4f91b0f8171689f2674c57a3a6c01";
const URL = `${BASE_URL}/${endpoint}`;

const getWeatherData = async (endpoint, params) => {
  try {
    const response = await axios.get(URL, {
      params: {
        ...params,
        appid: API_KEY,
        units: "metric",
      },
    });
    return response.data;
  } catch (error) {
    console.log("Error fetching weather data:", error.message);
    return null;
  }
};

module.exports = { getWeatherData };
