const readline = require("readline");

const {
  getCurrentWeather,
  getWeatherForecast,
} = require("./services/weatherService");

const r1 = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const promptUser = () => {
  r1.question("Masukkan nama kota: ", async (city) => {
    if (!city) {
      console.log("Nama Kota Tidak");
      promptUser();
      return;
    }
    console.log(`Memanggil data cuaca untuk ${city}...`);
  });
};
